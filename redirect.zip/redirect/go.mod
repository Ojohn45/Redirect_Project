module Redirect

go 1.26.0

require golang.org/x/crypto v0.57.0
